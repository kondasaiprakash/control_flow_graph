public class Calculator
{
    public int a ;
    public int b ;
    public int c ;
    public int z ;
    int x = 10;
    int y = 10;
    

    public void add()
    {
        int d = a + b + c;

    }
    public void sub()
    {
        int d = a- b-c;
    }
    public void mul()
    {
        int d = a*b;
    }
    public void div()
    {
        int d = a/z;
    }
}